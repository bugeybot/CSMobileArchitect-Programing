package com.example.nathanielgrattonprojecteventtracker;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class DashboardActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private RecyclerView eventRecyclerView;
    private EventAdapter eventAdapter;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Retrieve the logged-in user's ID from SharedPreferences
        SharedPreferences preferences = getSharedPreferences("EventTrackerPrefs", MODE_PRIVATE);
        userId = preferences.getInt("user_id", -1);

        // If the user ID is invalid, redirect to the login page
        if (userId == -1) {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        // Initialize database helper to interact with the SQLite database
        dbHelper = new DatabaseHelper(this);

        // Set up the RecyclerView to display the list of events
        eventRecyclerView = findViewById(R.id.eventRecyclerView);
        eventRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Load the events for the logged-in user
        loadEvents();

        // Set up the Settings button to navigate to the settings screen
        ImageButton settingsButton = findViewById(R.id.settingsButton);
        settingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
        });

        // Set up the Add Event button to show the Add Event dialog
        FloatingActionButton addEventButton = findViewById(R.id.addEventButton);
        addEventButton.setOnClickListener(v -> showAddEventDialog());
    }

    private void loadEvents() {
        // Fetch events for the current user from the database
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM events WHERE user_id = ?", new String[]{String.valueOf(userId)});

        List<Event> events = new ArrayList<>();
        while (cursor.moveToNext()) {
            // Map each database row to an Event object
            events.add(new Event(
                    cursor.getInt(0),  // Event ID
                    cursor.getString(1),  // Event name
                    cursor.getString(2),  // Event date
                    cursor.getString(3)   // Event time
            ));
        }
        cursor.close();

        // Pass the events to the adapter to populate the RecyclerView
        eventAdapter = new EventAdapter(events, this::deleteEvent);
        eventRecyclerView.setAdapter(eventAdapter);
    }

    private void deleteEvent(int eventId) {
        // Delete the selected event for the current user from the database
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete("events", "id = ? AND user_id = ?", new String[]{String.valueOf(eventId), String.valueOf(userId)});
        Toast.makeText(this, "Event Deleted", Toast.LENGTH_SHORT).show();

        // Reload the events list after deletion
        loadEvents();
    }

    private void showAddEventDialog() {
        // Create a dialog for adding a new event
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Event");

        // Inflate the custom layout for the Add Event dialog
        View view = getLayoutInflater().inflate(R.layout.dialog_add_event, null);
        builder.setView(view);

        // Get references to the input fields in the dialog
        androidx.appcompat.widget.AppCompatEditText eventNameInput = view.findViewById(R.id.eventNameInput);
        androidx.appcompat.widget.AppCompatEditText eventDateInput = view.findViewById(R.id.eventDateInput);
        androidx.appcompat.widget.AppCompatEditText eventTimeInput = view.findViewById(R.id.eventTimeInput);

        // Handle the Add button click
        builder.setPositiveButton("Add", (dialog, which) -> {
            String name = eventNameInput.getText().toString().trim();
            String date = eventDateInput.getText().toString().trim();
            String time = eventTimeInput.getText().toString().trim();

            // Validate input fields before adding the event
            if (!name.isEmpty() && !date.isEmpty() && !time.isEmpty()) {
                addEventToDatabase(name, date, time);
            } else {
                Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            }
        });

        // Handle the Cancel button click
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.create().show();
    }

    private void addEventToDatabase(String name, String date, String time) {
        // Insert the new event into the database for the current user
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("event_name", name);
        values.put("event_date", date);
        values.put("event_time", time);
        values.put("user_id", userId);  // Associate the event with the logged-in user

        long result = db.insert("events", null, values);
        if (result != -1) {
            Toast.makeText(this, "Event Added", Toast.LENGTH_SHORT).show();
            loadEvents();
        } else {
            Toast.makeText(this, "Error Adding Event", Toast.LENGTH_SHORT).show();
        }
    }
}