package com.example.nathanielgrattonprojecteventtracker;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText usernameField, passwordField;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new DatabaseHelper(this);
        usernameField = findViewById(R.id.usernameField);
        passwordField = findViewById(R.id.passwordField);

        Button loginButton = findViewById(R.id.loginButton);
        loginButton.setOnClickListener(this::loginUser);

        Button registerButton = findViewById(R.id.createAccountButton);
        registerButton.setOnClickListener(this::registerUser);
    }

    private void loginUser(View view) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String username = usernameField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();

        Cursor cursor = db.rawQuery("SELECT id FROM users WHERE username = ? AND password = ?", new String[]{username, password});
        if (cursor.moveToFirst()) {
            int userId = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            storeUserId(userId);
            Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, DashboardActivity.class));
            finish();
        } else {
            Toast.makeText(this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
        }
        cursor.close();
    }

    private void registerUser(View view) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        String username = usernameField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            return;
        }

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        long result = db.insert("users", null, values);
        if (result != -1) {
            Toast.makeText(this, "Account Created", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error Creating Account", Toast.LENGTH_SHORT).show();
        }
    }

    private void storeUserId(int userId) {
        SharedPreferences preferences = getSharedPreferences("EventTrackerPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt("user_id", userId);
        editor.apply();
    }
}
